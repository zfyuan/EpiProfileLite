function pepno = get_pepno(pepno_def,pepstr,special)
%%

c_pep_code = sum((pepstr-'0'+49).*log(special.pre_nums(1:length(pepstr))));
ix = find( special.pep_codes==c_pep_code );
if 1==isempty(ix)
    pepno = pepno_def;
else
    pepno = ix(1);
end