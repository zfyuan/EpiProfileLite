function HH2A_02oX_4_11(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,cur_outpath,special)
%%

% check
out_filename = 'HH2A_02oX_4_11';
% fprintf(1,'%s..',out_filename(2:end));
out_file0 = fullfile(cur_outpath,[out_filename,'.mat']);
if 0~=exist(out_file0,'file')
    return;
end

% init
His = init_histone();

% calculate
[pep_rts,pep_intens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,His,special);

% output
output_histone(cur_outpath,out_filename,His,pep_rts,pep_intens);

% draw
draw_layout(cur_outpath,out_filename,His,pep_rts,pep_intens);

function His = init_histone()
%%

His.pep_seq = 'GKTGGKAR';
His.mod_short = {'unmod';
    'K5ac';
    'K9ac';
    'K5acK9ac';
    'K9me1';
    'K5me1'};
His.mod_type = {'0,pr;2,pr;6,pr;';
    '0,pr;2,ac;6,pr;';
    '0,pr;2,pr;6,ac;';
    '0,pr;2,ac;6,ac;';
    '0,pr;2,pr;6,me1;';
    '0,pr;2,me1;6,pr;'};

His.pep_ch = repmat(2,length(His.mod_type),1);
%{
His.pep_mz = [942.5367	471.7720
    928.5211	464.7642
    928.5211	464.7642
    914.5054	457.7563
    956.5524	478.7798
    956.5524	478.7798];
%}
His.pep_mz = calculate_pepmz(His);

function [pep_rts,pep_intens] = calculate_layout(MS1_index,MS1_peaks,MS2_index,MS2_peaks,ptol,His,special)%#ok
%%

pepno = get_pepno(11,'H2A1_4_11',special);
[pep_rts,pep_intens] = get_histone1(MS1_index,MS1_peaks,ptol,His,pepno,length(special.pep_codes));

% K5ac/K9ac
hno = [2 3];
pepno = get_pepno(34,'H2AX_4_11 K5ac-K9ac',special);
[cur_rts1,cur_intens1,pep_ratio1] = get_histone2(MS2_index,MS2_peaks,hno,His,pepno,length(special.pep_codes));%#ok
for i=1:length(hno)
    pep_intens(hno(i)) = pep_intens(hno(i))*pep_ratio1(i);
end

% K5me1/K9me1
hno = [5 6];
pepno = get_pepno(35,'H2AX_4_11 K5me1-K9me1',special);
[cur_rts1,cur_intens1,pep_ratio1] = get_histone2(MS2_index,MS2_peaks,hno,His,pepno,length(special.pep_codes));%#ok
for i=1:length(hno)
    pep_intens(hno(i)) = pep_intens(hno(i))*pep_ratio1(i);
end