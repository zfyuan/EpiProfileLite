function [pep_rts,pep_intens] = get_most_column(pep_rts,pep_intens)
%%

[npep,mdata] = size(pep_intens);

non0 = zeros(1,mdata);
for jno=1:mdata
    non0(jno) = length(find(pep_intens(:,jno)>0));
end
[nmax,idx] = max(non0);
if nmax<npep
    ii = find(pep_intens(:,idx)==0);
    left_idx = setdiff(1:mdata,idx);
    for ino=1:length(ii)
        x1 = find(pep_intens(ii(ino),left_idx)>0);
        if 0==isempty(x1)
            pep_intens(ii(ino),idx) = pep_intens(ii(ino),left_idx(x1(1)));
        end
    end
end
pep_rts = pep_rts(1:npep,idx);
pep_intens = pep_intens(1:npep,idx);